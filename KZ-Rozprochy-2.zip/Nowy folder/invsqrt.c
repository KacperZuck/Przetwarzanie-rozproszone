#include <stdint.h>
#include <math.h>

float Prosta(float n) {
	return 1 / sqrt(n);
}

float FastInverse(float n) {

	union {
		float    f;
		uint32_t i;
	  } conv = { .f = n };
	  conv.i  = 0x5f3759df - (conv.i >> 1);
	  conv.f *= 1.5F - (n * 0.5F * conv.f * conv.f);
	  return conv.f;
}

