#include <stdio.h>
#include <time.h>

float Prosta(float x);
float FastInverse(float x);
float Prosta_2(float x);

int main() {
    float x = 34.26, wynik=0;

    printf("Liczba: %f\n", x);

    wynik = Prosta(x);
    printf("%f ", wynik);

    wynik = FastInverse(x); 
    printf("%f ", wynik);

    wynik = Prosta_2(x);
    printf("%f\n", wynik);

    // Pomiar czasu
    int i = 0;
    double time = 0;

    clock_t start = clock();
    while (i <= 1000000) {
        wynik = Prosta(x);
        i++;
    }
    clock_t end = clock();

    time = (double)(end - start) / CLOCKS_PER_SEC;
    printf("%lf sekund\n", time);

    // 2
     i = 0;
     time = 0;

     start = clock();
    while (i <= 1000000) {
        wynik = Prosta(x);
        i++;
    }
     end = clock();

    time = (double)(end - start) / CLOCKS_PER_SEC;
    printf("%lf sekund\n", time);

    // 3
     i = 0;
     time = 0;

     start = clock();
    while (i <= 1000000) {
        wynik = Prosta_2(x);
        i++;
    }
     end = clock();

    time = (double)(end - start) / CLOCKS_PER_SEC;
    printf("%lf sekund\n", time);

    return 0;
}