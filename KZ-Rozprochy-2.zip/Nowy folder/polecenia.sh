#!/bin/bash

echo " Tworzenie biblioteki"
gcc -c -Wall -fPIC -D_GNU_SOURCE invsqrt.c -lm
gcc -c -Wall -fPIC -D_GNU_SOURCE opt_invsqrt.c -lm
gcc opt_invsqrt.o invsqrt.o -shared -o lib_arytmdyn.so -lm

echo " Wywołanie pliku"
echo " "
gcc -c Dynamika.c -o Dynamika.o -lm
gcc Dynamika.o -L . -l_arytmdyn -o Dynamika.out -lm
export LD_LIBRARY_PATH=.:$LD_LIBRARY_PATH   #udostępnienie biblioteki/ zmienna środowiskowa
./Dynamika.out


# DO URUCHOMIENIA
# chmod -x polecenia.sh
# ./poleceania.sh