#include <stdio.h>
#include <math.h>


float Prosta_2(float n) {
	return 1 / sqrtf(n);
}
